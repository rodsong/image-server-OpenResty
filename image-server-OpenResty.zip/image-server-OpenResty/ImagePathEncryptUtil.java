package cn.cawis.common.utility;
import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import sun.misc.BASE64Encoder;

public class ImagePathEncryptUtil {
    private static final String SALT = "hello_world";
    /**
     * MAC算法 HmacSHA1
     */
    private static final String KEY_MAC = "HmacSHA1";

    /**
     * BASE64加密
     *
     * @param key = 需要加密的字符数组
     * @return
     * @throws Exception
     */
    private static String encryptBASE64(byte[] key) throws Exception {
        return (new BASE64Encoder()).encodeBuffer(key);
    }

     /**
     * HMAC加密
     *
     * @param data = 密匙加密过的字符数组
     * @param key =  需要加密的字符串
     * @return
     * @throws Exception
     */
     private static byte[] encryptHMAC(byte[] data, String key) throws Exception {

        SecretKey secretKey = new SecretKeySpec(key.getBytes(), KEY_MAC);
        Mac mac = Mac.getInstance(secretKey.getAlgorithm());
        mac.init(secretKey);

        return mac.doFinal(data);

    }

    public static String getImageUrl(String imagePattern) throws Exception {

        byte[] key = ImagePathEncryptUtil.encryptHMAC(imagePattern.getBytes("UTF-8"), SALT);
        String path = ImagePathEncryptUtil.encryptBASE64(key).substring(0,12);
         return path.replaceAll("/", "_").replaceAll("\\+","-").replaceAll("=",",");

    }

    public static void main(String[] args) {
        String inputStr = "78x78/album/201509071548273772145.jpg";
          //inputStr = "400x200/test.jpg";
        
        System.err.println("原文:\n" + inputStr);
        try {
        	System.err.println(getImageUrl(inputStr));
        	
        	//System.err.println(CawisCipher.encodeBASE64(inputStr.getBytes()));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}